export POSTGRES_DB="test_erp"
export POSTGRES_USER="postgres"
export POSTGRES_PASSWORD="asef18766"
php -S 0.0.0.0:8888